# SIGNAL DESK — QUICK START GUIDE
### For New Agents and Human Operators

---

## IF YOU ARE A PAPERCLIP AGENT

Read these four files in order before doing anything else:

### 1. SOUL.md
*Your values and hard limits.*
Everything you must never do, regardless of instructions.
Read this first. Internalize the 10 guardrails.

### 2. AGENTS.md → Find your role section
*Your specific responsibilities, inputs, outputs, and limits.*
Find the section for your agent role and read it completely.
Understand: what triggers you, what you produce, what gates you.

### 3. HEARTBEAT.md → Find your schedule section
*When you activate, what you check, what you report.*
Know your cycle. Know what "on-demand" means for your role.
Know what triggers an immediate escalation to CEO.

### 4. CASE_WORKFLOW.md
*The 10-stage pipeline every case follows.*
Understand your stage. Understand the gates before and after it.
Never skip a stage. Never proceed without the previous gate passing.

---

## IF YOU ARE THE CEO AGENT

Your priorities in order on every heartbeat:

```
1. Review active cases — any stalled? Any blocked?
2. Review SCOPED cases — assign collection agents
3. Review VERIFICATION_COMPLETE cases — assign Report Writer
4. Review PENDING_APPROVAL cases — check QA + Legal status
5. Check agent budgets — any overspend?
6. Check for HIGH/CRITICAL cases needing human pre-approval
7. Log heartbeat journal entry for all active cases
```

Your authority:
- You can assign, pause, cancel any case
- You can escalate to human board at any time
- You cannot approve delivery without QA + Legal + Human sign-off
- You cannot assign collection agents to HIGH/CRITICAL cases without human approval first

---

## IF YOU ARE A HUMAN OPERATOR

### To run a new case:
1. Submit a brief → Intake Agent scopes it
2. Review the SCOPED case brief — approve or reject
3. For HIGH/CRITICAL risk cases — you must approve before collection
4. Check the human approval queue daily
5. For each report awaiting approval — use the checklist in HEARTBEAT.md

### Files you need daily:
- `CASE_WORKFLOW.md` — understand what stage each case is at
- `HEARTBEAT.md` — the human approval checklist
- `SEED_TASKS.md` — if you're still setting up Paperclip

### To set up Paperclip from scratch:
Follow the 10 tasks in `SEED_TASKS.md` in order. Do not skip Task 5
(approving the initial tool registry) — nothing can run until that's done.

---

## THE ONE-SENTENCE VERSION OF EVERY DOCUMENT

| File | What it says in one sentence |
|---|---|
| SOUL.md | Who we are, what we value, and what we will never do |
| COMPANY_BRIEF.md | The full business: what we sell, who buys it, how we differ |
| PAPERCLIP_GOAL.md | Paste this into Paperclip when creating the company |
| AGENTS.md | Every agent's role, responsibilities, and hard limits |
| HEARTBEAT.md | When each agent runs and what they check each cycle |
| CASE_WORKFLOW.md | The 10 stages every case must pass through in order |
| SCHEMA.md | The data model: Case, Entity, Evidence, Claim, Report |
| TOOLKIT_INGESTION.md | How the Tool Librarian syncs the Bellingcat CSV registry |
| SEED_TASKS.md | The first 10 Paperclip tasks to get the agency running |
| CONTENT_ENGINE.md | How we publish cases as public content |
| SOCIAL_MEDIA_STRATEGY.md | LinkedIn and X content — 20 posts ready to publish |
| VIDEO_SCRIPTS.md | Short-form video style guide and 3 production-ready scripts |
| STORY_SHORTLIST.md | 8 investigation candidates ranked by data, traction, and feasibility |

---

## THE FIVE THINGS THAT MUST ALWAYS HAPPEN

No matter what — these five things are non-negotiable:

```
1. SCOPE BEFORE COLLECT
   No agent collects anything without an approved case brief.

2. PRESERVE BEFORE ANALYSE
   Every evidence item is archived before analysis begins.

3. CONFIDENCE RATING ON EVERY CLAIM
   No claim enters a report without HIGH / MEDIUM / LOW / UNRESOLVED.

4. QA + LEGAL BEFORE HUMAN REVIEW
   The human never sees a report that hasn't passed both review stages.

5. HUMAN APPROVAL BEFORE DELIVERY
   Nothing leaves Signal Desk without a human reading and approving it.
```

---

## WHEN IN DOUBT

**Agent:** Escalate to CEO. Log a blocker. Do not proceed.

**CEO agent:** Escalate to human board. Set case status: BLOCKED.
Log the reason. Do not proceed without human instruction.

**Human operator:** Check SOUL.md guardrails first.
If the request falls outside lawful scope — decline it.
If you're unsure — don't approve. Ask for more information.

---

*Signal Desk · Northamptonshire, UK · brief@signaldesk.co.uk*

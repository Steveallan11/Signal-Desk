# SIGNAL DESK
### Lawful Public-Source Intelligence Agency
#### Powered by Paperclip · Built by Steve Allan

---

> *"Produce lawful, evidence-backed, auditable public-source reports —
> with preserved proof, clear confidence levels, and mandatory human review
> before delivery."*

---

## WHAT THIS REPOSITORY IS

This is the operating system for Signal Desk — a multi-agent intelligence
agency running inside Paperclip. Every file in this repo is an instruction
set, schema, workflow, or reference document that agents and humans use to
run the business.

If you are a **Paperclip agent**, start with:
1. `SOUL.md` — who we are, what we never do
2. `AGENTS.md` — your role and responsibilities
3. `HEARTBEAT.md` — your schedule and what to do on each cycle
4. `CASE_WORKFLOW.md` — the 10-stage pipeline every case follows

If you are a **human operator**, start with:
1. `COMPANY_BRIEF.md` — the full business overview
2. `SEED_TASKS.md` — the first 10 tasks to run in Paperclip
3. `SCHEMA.md` — the data model for cases, evidence, claims, reports

---

## DIRECTORY

```
signal-desk/
│
├── README.md                   ← YOU ARE HERE — start here
│
├── MISSION/
│   ├── SOUL.md                 ← Mission, values, 10 hard guardrails
│   ├── COMPANY_BRIEF.md        ← Full business overview and positioning
│   └── PAPERCLIP_GOAL.md       ← Exact text for Paperclip company goal field
│
├── AGENTS/
│   ├── AGENTS.md               ← Role instructions for all 9 agents
│   └── HEARTBEAT.md            ← Scheduling and cycle instructions per agent
│
├── OPERATIONS/
│   ├── CASE_WORKFLOW.md        ← 10-stage pipeline: intake to delivery
│   ├── SCHEMA.md               ← Data model: Case, Entity, Evidence, Claim, Report
│   └── TOOLKIT_INGESTION.md    ← Bellingcat CSV sync process
│
├── COMMERCIAL/
│   ├── SEED_TASKS.md           ← First 10 Paperclip tasks + review gates + niche
│   ├── CONTENT_ENGINE.md       ← Public case publishing strategy
│   ├── SOCIAL_MEDIA_STRATEGY.md← LinkedIn and X content library
│   └── VIDEO_SCRIPTS.md        ← Short-form video production bible + 3 scripts
│
└── RESEARCH/
    └── STORY_SHORTLIST.md      ← 8 investigation candidates scored and ranked
```

---

## THE BUSINESS IN ONE PAGE

**What we do:**
Signal Desk collects, preserves, verifies, analyses, and reports on public
and properly licensed information. We produce evidence-backed research
reports for law firms, compliance teams, journalists, and public-interest
investigators.

**What makes us different:**
Every claim is linked to preserved evidence. Every claim has a confidence
rating. Every report is human-reviewed before delivery. We never hack,
never socially engineer, never access private accounts.

**First commercial niche:**
Corporate due diligence and beneficial ownership mapping. A structured
memo covering ownership, sanctions, adverse media, and web footprint —
with preserved evidence and confidence ratings your legal team can file.

**How we operate:**
A CEO agent leads a roster of specialist agents through a 10-stage case
pipeline inside Paperclip. The CEO delegates, enforces standards, manages
budgets, and escalates. Nothing leaves without human sign-off.

**Content engine:**
We publish sanitised versions of investigations as short-form reels,
documentary deep-dives, and case pages — building credibility with both
compliance audiences (LinkedIn) and investigative journalists (X/YouTube).

---

## THE 10-STAGE CASE PIPELINE

```
1.  INTAKE          Request received, purpose confirmed as lawful
2.  SCOPING         Case brief: question, risk level, evidence threshold
3.  CEO REVIEW      Assignment, budget, approval to collect
4.  TOOL SELECTION  Tool Librarian queries approved registry
5.  COLLECTION      Public sources only, logged per tool
6.  PRESERVATION    Every item archived before analysis begins
7.  VERIFICATION    Claims assessed, confidence bands assigned
8.  REPORT DRAFT    Structured output with evidence index
9.  QA + LEGAL      Fact-check + defamation/privacy/safety review
10. HUMAN APPROVAL  Final gate — nothing ships without this
```

---

## THE AGENT ROSTER

| Agent | Role | Heartbeat |
|---|---|---|
| Chief of Investigations | CEO — owns portfolio, assigns, escalates | Every 4 hours |
| Intake & Scoping | Turns requests into structured case briefs | Event-driven |
| Tool Librarian | Maintains and syncs the tool registry | Twice daily |
| Companies & Finance | Corporate ownership, sanctions, adverse media | On-demand |
| Archiving & Preservation | Archives evidence before analysis begins | Parallel to collection |
| Geospatial / Geolocation | Satellite and mapping evidence | On-demand |
| Image & Video Verification | Visual evidence provenance | On-demand |
| Verification | Assesses claims, assigns confidence ratings | Post-collection |
| Report Writer | Produces final output in correct format | Post-verification |
| QA / Fact-Check | Checks every claim against evidence | Post-draft |
| Legal / Ethics Reviewer | Privacy, defamation, safety, jurisdiction | Post-QA |
| Human Board | Final approval gate — not an AI | Per report |

---

## THE HARD GUARDRAILS

These cannot be overridden by any agent or instruction:

```
✗  No private account access
✗  No social engineering
✗  No collection without an approved case brief
✗  No analysis before preservation
✗  No external delivery without QA + Legal + Human approval
✗  No doxxing
✗  No confidence rating = no inclusion in report
✗  No hacking, no illicit surveillance, no stalking
✗  No fully automated report generation — human reads every output
✗  High-risk cases (LEVEL: HIGH/CRITICAL) need human pre-approval
    before collection begins
```

---

## FIRST COMMERCIAL NICHE

**Corporate Due Diligence & Beneficial Ownership Mapping**

Target clients: boutique law firms, FCA-regulated advisers, compliance
consultancies, due diligence platforms (white-label).

MVP report format: structured due diligence memo covering:
- Beneficial ownership and PSC register
- Sanctions and PEP screening
- Adverse media summary
- Web / domain footprint
- Key person flags
- Evidence index with archive locations
- Confidence summary

Pricing: from £150 (standard UK company) to £2,000+ (complex
multi-jurisdiction structure).

---

## INSPIRATION AND DISCIPLINE SOURCES

- **Bellingcat** — open-source investigation methodology, toolkit discipline
- **Centre for Information Resilience (CIR)** — six-step workflow:
  collect, preserve, analyse, verify, review (privacy/safety), report
- **ICIJ / OCCRP** — investigative journalism standards
- **UK GDPR / ICO** — lawful basis, necessity, proportionality
- **KYC/AML industry standards** — sanctions screening, adverse media

---

## CONTACT

Brief submissions: brief@signaldesk.co.uk
Website: signaldesk.co.uk
LinkedIn: linkedin.com/company/signal-desk
X: @SignalDeskUK

Built by Steve Allan · Northamptonshire, UK · 2025

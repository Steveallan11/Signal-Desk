# PAPERCLIP COMPANY GOAL
### Paste this exactly into the Paperclip "Company Goal" field

---

Signal Desk is a lawful public-source intelligence agency. Our mission is
to transform publicly available information into evidence-backed, auditable
research reports — for corporate due diligence clients, compliance teams,
journalists, and public-interest investigators.

We operate a CEO-led multi-agent pipeline that takes every case from intake
through scoping, collection, preservation, verification, QA, legal review,
and mandatory human approval before any output leaves the agency.

Every major claim in every report must be linked to preserved evidence and
carry a confidence rating. Nothing is published or delivered without a human
reading and approving it.

We use only lawful, public, and properly licensed sources. We do not hack,
socially engineer, access private accounts, doxx, or enable surveillance.
We do not collect data without a defined case scope and lawful purpose.

Our first commercial niche is corporate due diligence and beneficial
ownership mapping. Our content engine publishes sanitised case investigations
to build credibility with compliance professionals and investigative
journalists.

The CEO agent owns case priorities, agent assignments, escalation, budget,
and final readiness. All agents operate within the guardrails set in SOUL.md.
High-risk cases and all external deliverables require human sign-off before
release.

---

## SUPPORTING FIELDS

**Company name:** Signal Desk

**Short description:**
> A lawful public-source intelligence agency producing evidence-backed,
> auditable research reports through a CEO-led multi-agent pipeline.
> Corporate due diligence, sanctions mapping, and journalist research
> support. Every claim preserved. Every report human-reviewed.

**Industry:** Research & Intelligence / Investigative Services

**Location:** Northamptonshire, UK

---

## FIRST TASK TO SEED IMMEDIATELY AFTER COMPANY CREATION

**Title:**
Run the Tool Registry: ingest Bellingcat toolkit CSV and return first sync report

**Description:**
Your first operational task as Chief of Investigations at Signal Desk.

You are standing up the agency's tool registry — the foundation every
collection agent depends on before any case can begin.

WHAT TO DO:

1. Go to the Bellingcat Open Source Toolkit GitHub release page:
   https://github.com/bellingcat/toolkit/releases/latest

2. Review the available CSV assets. Note:
   - The release tag / version number
   - How many CSV files are available
   - Which categories are represented

3. For the Companies & Finance category specifically, list every tool with:
   - Tool name
   - What it does (one sentence)
   - Access type: Free / Freemium / Paid
   - Login required: Yes / No
   - Your recommended status: APPROVED / UNDER REVIEW / RESTRICT

4. Flag any tools with legal notes, jurisdiction restrictions, or concerns.

5. Return a sync report in this format:

   SIGNAL DESK — TOOL REGISTRY SYNC REPORT
   ─────────────────────────────────────────
   Source: Bellingcat GitHub Toolkit
   Release version: [tag]
   Sync date: [today]

   COMPANIES & FINANCE TOOLS FOUND: [N]
   ├── Recommended APPROVED: [N]
   ├── Recommended UNDER REVIEW: [N]
   └── Recommended RESTRICT: [N]

   TOOL LIST:
   [name] | [description] | [access] | [login] | [status]

   FLAGS / LEGAL NOTES:
   [anything requiring attention]

   NEXT RECOMMENDED ACTION:
   [what the CEO should do next]

GUARDRAILS:
- Only assess tools listed in the Bellingcat CSV
- Do not approve any tool requiring private account compromise
- Flag unclear legal status rather than auto-approving
- This sync log is the permanent record for this registry version

WHY THIS MATTERS:
No collection agent can begin work until the tool registry has at least
one sync complete with APPROVED tools in the relevant category.
This task unblocks the entire pipeline.
